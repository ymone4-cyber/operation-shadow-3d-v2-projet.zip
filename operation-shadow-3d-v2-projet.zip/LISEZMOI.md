# Operation Shadow 3D v2 — Créateur : MONé

Jeu de tir 3D à la troisième personne en HTML + Three.js (r128). Carte : Savane africaine.

## Contenu
- `www/` : le jeu (index.html), PWA (manifest.json, sw.js, icônes), dossier `models/` pour le personnage GLB.
- `.github/workflows/build.yml` : copie les bibliothèques 3D, télécharge le modèle Soldier.glb, compile l'APK et publie la PWA.

## Étapes (GitHub)
1. Crée un dépôt sur github.com et envoie tout ce dossier (garde `.github`). La branche doit s'appeler `main`.
2. Réglages > Pages > Source : "GitHub Actions".
3. Onglet Actions > "Build APK et PWA" > Run workflow (5 à 10 min).
4. APK : télécharge l'artefact "operation-shadow-3d-apk" (zip avec app-debug.apk), installe-le sur Android.
5. PWA : ouvre l'adresse https://TON-COMPTE.github.io/NOM-DU-DEPOT/ sur Chrome Android > menu > "Installer l'application".

## Personnage humain
Si `www/models/soldier.glb` est présent (téléchargé par le workflow), le jeu l'utilise avec les animations Idle / Walk / Run. Sinon, personnage procédural articulé. Tu peux remplacer le fichier par ton propre GLB (animations nommées Idle, Walk, Run). Vérifie la licence Mixamo avant toute publication commerciale.

## Test local sur PC
Mets three.min.js, GLTFLoader.js, SkeletonUtils.js dans `www/`, puis `npx serve www` et ouvre l'adresse affichée.

## Limites
APK debug (pas Play Store). Pas de tir/rechargement animé sur le modèle GLB (animations de déplacement seulement). Jeu non testé sur téléphone.
